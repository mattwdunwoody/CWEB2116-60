﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	class ArithmeticOperations
	{
		public int addNums(int num1, int num2)
		{
			return num1 + num2;
		}

		public int subtract(int num1, int num2)
		{
			return num1 - num2;
		}

		public int multiply(int num1, int num2)
		{
			return num1 * num2;
		}

		public int divide(int num1, int num2)
		{
			return num1 / num2;
		}

		public int modulus(int num1, int num2)
		{
			return num1 % num2;
		}

	}
}
